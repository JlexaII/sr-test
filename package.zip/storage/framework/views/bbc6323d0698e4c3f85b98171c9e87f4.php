

<?php $__env->startSection('content'); ?>
<h2 class="mt-6">Zakaz qilingan</h2>
<h1 class="p-6">Olib ketish</h1>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\sr-test\resources\views/auth/inc/zakaz.blade.php ENDPATH**/ ?>