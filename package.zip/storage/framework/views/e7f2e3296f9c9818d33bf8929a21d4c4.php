<div class="container py-1">

    <header class="d-flex justify-content-center">
        <div class="dropdown">
            <a href="#" class="bs-primary-border-subtle btn d-flex align-items-center link-dark text-decoration-none dropdown-toggle"
                data-bs-toggle="dropdown" aria-expanded="false">
                <img src="/images/access.png" alt="" width="52" height="52" class="rounded-circle me-2">
                <strong><?php echo e(request()->user()->email); ?></strong>
            </a>
            <ul class="dropdown-menu text-small shadow">
                <li><a class="dropdown-item" href="<?php echo e(route('sozlama')); ?>">Sozlama</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('profil')); ?>">Profil</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="/">Chiqish</a></li>
            </ul>
        </div>

        <ul class="align-items-center nav nav-pills">
            <li class="nav-item"><a href="<?php echo e(route('bozor')); ?>" class="nav-link">Bozor</a></li>
            <li class="nav-item"><a href="<?php echo e(route('narxlar')); ?>" class="nav-link">Narxlar</a></li>
            <li class="nav-item"><a href="<?php echo e(route('yordam')); ?>" class="nav-link">Yordam</a></li>
            <li class="nav-item"><a href="<?php echo e(route('komp')); ?>" class="nav-link">Kompaniya</a></li>
        </ul>
    </header>
</div>
<?php /**PATH C:\OSPanel\domains\sr-test\resources\views/auth/inc/header.blade.php ENDPATH**/ ?>