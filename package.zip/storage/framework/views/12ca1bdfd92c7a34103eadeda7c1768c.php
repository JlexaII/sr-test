

<?php $__env->startSection('content'); ?>
    <h1 class="p-5">Profil</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\sr-test\resources\views/auth/inc/profil.blade.php ENDPATH**/ ?>