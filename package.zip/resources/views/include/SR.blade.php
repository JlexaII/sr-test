@section('SRHaqida')
    
<!-- Modal Silks Roads haqida maylumot-->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Silks Roads</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          "AXMEDOV's" MChJ Companiyasi ostida ochilgan marketplace. Guvohnoma № 637738
          <br>Tovarlar sotish uchun ro'yhatdan o'tish lozim
          Ellikdan yuqori tovarlarni joylashirish uchun tarif rejasidan foydalaning.
          <br>Bizning xizmatlarimiz endi yo'lga qo'yildi.
          <br>Barcha savolaringizni +998 33 360 60 28 raqamiga telefon qilib so'rab olishingiz mumkin.
          <br>Tovar ishlab-chiqaruvchilarni hamkorlikga chaqiramiz.
          Murojaat uchun e-mail: support@silksroads.uz
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
          <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
        </div>
      </div>
    </div>
  </div>