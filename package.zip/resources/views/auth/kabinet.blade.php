@extends('auth.Layouts.app')

@section('title-block')
    Kabinet
@endsection

@section('content')
    <h1 class="p-5">Bosh sahifa hammasi pod kontroller nu konechno vse budet horosho</h1>
@endsection