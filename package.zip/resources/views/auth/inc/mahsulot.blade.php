@extends('auth.Layouts.app')

@section('content')
    <h1 class="p-5">Mahsulot</h1>
@endsection