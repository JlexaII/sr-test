@extends('auth.Layouts.app')

@section('content')
<h2 class="mt-6">Zakaz qilingan</h2>
<h1 class="p-6">Olib ketish</h1>    
@endsection