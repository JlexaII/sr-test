    @extends('auth.Layouts.app')

    @section('content')
    <h1 class="mt-5">Content 2 Panel</h1>
    @endsection
    