@extends('auth.Layouts.app')

@section('content')
    <h1 class="p-5">Sozlama</h1>
@endsection