@extends('auth.Layouts.app')

@section('content')
    <h1 class="p-5">Profil</h1>
@endsection